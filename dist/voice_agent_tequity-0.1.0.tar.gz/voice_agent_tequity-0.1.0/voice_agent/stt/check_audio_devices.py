from base import  SpeechToText

api_key="3294cac533734554b16271ce993b897c"

stt=SpeechToText(api_key)

stt.start()