from  speech_to_text  import  SpeechToText
stt=SpeechToText(api_key="3294cac533734554b16271ce993b897c")

output=stt.start()



